package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Employee;
import com.example.repository.EmployeeRepository;
import com.example.service.EmployeeService;

import jakarta.websocket.server.PathParam;

@RestController
public class Controller {
	
	 @Autowired //(required = false)
	    public EmployeeService employeeService;
	 /*
	 public Controller(EmployeeService employeeService) {
	        this.employeeService = employeeService;
	    }
	    */
	
	@GetMapping("/getDemo")
	public String getDemo()
	{
		return "welcome to srping boot demo";
		
	}
	
	// params are mandatory to enter at runtime
	@PostMapping("/postDemo")
	public String postDemo(@RequestParam(value = "name") String name)
	{
		return "spring boot post method demo with name="+name;
		
	}
	
	
	// params not mandatory to enter at runtime
	@PostMapping("/postDemo2")
	public String postDemo2(@PathParam(value = "name") String name)
	{
		return "spring boot post method demo with name="+name;
		
	}
	
	 @GetMapping("/allEmps")
	    public ResponseEntity<List<Employee>> getAllEmp(){
		 return new ResponseEntity<List<Employee>>(employeeService.getAllEmployee(),HttpStatus.OK);
			
	       
	    }
	 
	// spring.datasource.driver-class-name=com.mysql.jdbc.Driver

	/*
	 @GetMapping("/allEmps")
	    public ResponseEntity<List<Employee>> getAllEmp(){
		 return new ResponseEntity<List<Employee>>(employeeService.getAllEmployee(),HttpStatus.OK);
			
	       
	    }
	 
	 @PostMapping("/saveEmp")
	    public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){
	        return new ResponseEntity<Employee>(employeeService.saveEmployee(employee), HttpStatus.CREATED);
	    }
	    //GetAll Rest Api
	    @GetMapping("/all")
	    public List<Employee> getAllEmployee(){
	        return employeeService.getAllEmployee();
	    }

	    //Get by Id Rest Api
	    @GetMapping("/emp/{id}")
	    // localhost:8080/api/employees/1
	    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") long employeeID){
	        return new ResponseEntity<Employee>(employeeService.getEmployeeById(employeeID),HttpStatus.OK);
	    }

	    //Update Rest Api
	    @PutMapping("/updateEmp/{id}")
	    public ResponseEntity<Employee> updateEmployee(@PathVariable("id") long id,
	                                                   @RequestBody Employee employee){
	        return new ResponseEntity<Employee>(employeeService.updateEmployee(employee,id),HttpStatus.OK);
	    }

	    //Delete Rest Api
	    @DeleteMapping("/deleteEmp/{id}")
	    public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id){
	        //delete employee from db
	        employeeService.deleteEmployee(id);
	        return new ResponseEntity<String>("Employee deleted Successfully.",HttpStatus.OK);
	    }
*/
}
